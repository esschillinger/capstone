def get_vocab_list(unit, native_language, target_language):

    return